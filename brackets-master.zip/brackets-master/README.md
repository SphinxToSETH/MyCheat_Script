# Dracula for [Brackets](http://brackets.io)

> A dark theme for [Brackets](http://brackets.io).

## Install

This extension requires Brackets Release 1.0 or newer.

1. Open Brackets
2. Open the Extension Manager
3. Switch to "Themes" tab
4. Search for "Dracula Zeno Rocha"
5. Click "Install"

## License

[MIT License](./LICENSE)
