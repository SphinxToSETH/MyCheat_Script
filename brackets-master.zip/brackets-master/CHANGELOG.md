Changelog
=========

1.0.0
-----

- [NEW] Included theme.css file containg all Dracula color styles.
